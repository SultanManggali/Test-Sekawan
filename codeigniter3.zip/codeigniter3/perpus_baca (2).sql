-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2024 at 03:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpus_baca`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `synopsis` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `country`, `language`, `genre`, `publisher`, `publish_date`, `pages`, `synopsis`, `image_url`) VALUES
(40, 'Avanza', '1000', '', '', '11', '', '0000-00-00', 0, '', 'fifa.png'),
(41, 'Avanza', '1000', '', '', '11', '', '0000-00-00', 0, '', 'bla.png'),
(42, 'Avanza', '1000', '', '', '11', '', '0000-00-00', 0, '', 'fifa.png'),
(43, 'Avanza', '1000', '', '', '11', '', '0000-00-00', 0, '', 'details-3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `tanggal_pesan` date DEFAULT NULL,
  `jenis_kendaraan` varchar(50) DEFAULT NULL,
  `penjemputan` varchar(300) DEFAULT NULL,
  `penurunan` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `name`, `tanggal_pesan`, `jenis_kendaraan`, `penjemputan`, `penurunan`) VALUES
(72, 'sultan', '0000-00-00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `password`, `level`) VALUES
(1, 'sultan', '$2y$10$J/sF4UJDOWcdtor7ysHXUem2bPLUkmHucBUJlR5rzV1sHyNsue372', 'userpremium'),
(2, 'mamat', '$2y$10$KuJ.EqlJXb31UXpduVyoVesaAiCyd/KXh1nQpwBYhd2yaPF7iznt6', 'user'),
(4, 'aryaelek', '$2y$10$VtdiDI0Ftc.k5FwK1S1UouYDQbTzF5IQwJg4DKJktOz9nqE0Ndo5e', 'user'),
(5, 'Pakde Tomy', '$2y$10$.RmyifDih.YeFU/AbKSnKOPnMyG0o1IdBvlds9L2ZzcmplvwEYQ2i', 'user'),
(6, 'lenovo', '$2y$10$9RWEUh4Z7059ti2VCSXIB.DCu/f8xR6.KqYSFvQYs6frGtI3.NNx.', 'admin'),
(7, 'mindut', '$2y$10$x5sE7N7BPAGRWFVvh4dcJ.50B6d8/w.ojTSyMornKzqYY0.SkzfpK', 'user'),
(8, 'akmal', '$2y$10$3G2vl.SwM0xjkSN2D38kTu4mPSMtmVuSSOVlPPFCQyApm4saT5UQO', 'admin'),
(9, 'zidan', '$2y$10$WAyTYWQJvLFKl3eW61a2nuAQijM25eLwurgUfWhmlKIASv2dUtSAy', 'user'),
(10, 'cigul', '$2y$10$O9O4BHbWPzIXyFixDmRBMu/M79tkPfBHAI8AyjeRk.8jF4Pu2Om9q', 'penerbit'),
(11, 'mama', '$2y$10$9sIeZa71o/CiQf6S6QYxeuXk1D0xZjHjEPY4TX3W5WGqRq.WcKV6K', 'user'),
(12, 'tegar', '$2y$10$O7r1fAiB9X06oNcuaYaCR.ahX9DkOHtLtOoNDSKFZelcKxy5ZvGje', 'user'),
(13, 'ayah', '$2y$10$NyYPPZ5ReJHZ4/kZGMJ0te9vBovmk4r60qOXJXFojdIck6CG6CkMC', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
