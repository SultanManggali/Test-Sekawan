
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book_model extends CI_Model {

    public function save_book($data) {
        // Insert data into 'books' table
        $this->db->insert('books', $data);
    }

    public function get_all_books() {
        // Get all books from 'books' table
        $query = $this->db->get('books');
        return $query->result();
    }

    public function get_book_by_id($id) {
        // Mengambil data buku berdasarkan ID
        $query = $this->db->get_where('books', array('id' => $id));
        return $query->row_array();
    }

    public function add_book($data) {
        // Menambahkan data buku ke tabel 'books'
        return $this->db->insert('books', $data);
    }

    public function edit_book($id, $data) {
        // Mengedit data buku berdasarkan ID
        $this->db->where('id', $id);
        return $this->db->update('books', $data);
    }

    public function delete_book($id) {
        // Menghapus data buku berdasarkan ID
        $this->db->where('id', $id);
        return $this->db->delete('books');
    }

    // Add more functions as needed

}
