<?php
// Konfigurasi koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "perpus_baca";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = $_POST['nama'];
    $tanggal_pesan = $_POST['tanggal_pesan'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $penjemputan = $_POST['penjemputan'];
    $penurunan = $_POST['penurunan'];

    // Query untuk menyimpan data ke database
    $sql = "INSERT INTO transaksi (name, tanggal_pesan, jenis_kendaraan, penjemputan, penurunan) VALUES ('$nama', '$tanggal_pesan', '$jenis_kendaraan', '$penjemputan', '$penurunan')";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil disimpan ke database.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Tutup koneksi
$conn->close();
?>

