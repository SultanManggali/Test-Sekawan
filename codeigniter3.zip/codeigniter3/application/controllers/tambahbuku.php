<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tambahbuku extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url'); // Load URL Helper
    }

    public function index() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "perpus_baca";

        // Membuat koneksi
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $country = $_POST['country'];
            $language = $_POST['language'];
            $genre = $_POST['genre'];
            $publisher = $_POST['publisher'];
            $publish_date = $_POST['publish_date'];
            $pages = $_POST['pages'];
            $synopsis = $_POST['synopsis'];

            // Lokasi folder untuk menyimpan file
            $uploadDir = 'assets/gambar/';
            $uploadFile = $uploadDir . basename($_FILES['image']['name']);

            // Proses upload
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
                // Simpan informasi ke database
                $image = $_FILES['image']['name'];
                $sql = "INSERT INTO books (title, author, country, language, genre, publisher, publish_date, pages, synopsis, image_url) VALUES ('$title', '$author', '$country', '$language', '$genre', '$publisher', '$publish_date', '$pages', '$synopsis', '$image')";

                if ($conn->query($sql) === TRUE) {
                    echo "Data buku berhasil disimpan ke database.";

                    // Redirect to another page
                    redirect('admin/bukuadmin');
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "Gagal mengupload file.";
            }
        }
    }
}
