<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function index()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if ($this->form_validation->run() == false){
            $this->load->view('auth/Vlogin');
        } else{
            $this->_masuk();
        }
        
    }

    private function _masuk()
    {
        $nama = $this->input->post('nama');
        $password = $this->input->post('password');

        $user = $this->db->get_where('user', ['nama' => $nama])->row_array();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $data = [
                    'nama' => $user['nama'],
                    'level' => $user['level'], // Tambahkan level ke dalam session
                ];

                $this->session->set_userdata($data);

                // Redirect sesuai dengan level pengguna
                if ($user['level'] == 'admin') {
                    redirect('admin/dasboard'); // Ganti 'admin/dashboard' dengan halaman admin
                } elseif ($user['level'] == 'userpremium') {
                    redirect('userpremium/index'); // Ganti 'userpremium/dashboard' dengan halaman user premium
                } elseif ($user['level'] == 'penerbit') {
                    redirect('penerbit/index'); // Ganti 'penerbit/dashboard' dengan halaman penerbit
                } else {
                    redirect('user/index'); // Ganti 'user/dashboard' dengan halaman user biasa
                }
            } else {
                $this->session->set_flashdata('notif', '<div class="alert alert-danger" role="alert">Password Salah !</div>');
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-danger" role="alert">Username Belum Terdaftar !</div>');
            redirect('auth');
        }
    }


    public function Vregister()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[8]|matches[password2]', [
            'matches' => 'Password Tidak Cocok !',
            'min_length' => 'Password Minimal Memiliki 8 Karakter !'
        ]);
        $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]', [
            'matches' => 'Password Tidak Cocok !'
        ]);

        if ($this->form_validation->run() == false) {
            
            $this->load->view('auth/Vregister');
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'level' => 'user',
            ];

            $this->db->insert('user', $data);
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Akun Berhasil Terdaftar!</div>');
            redirect('auth');
        }
    }

    public function keluar()
    {

        $this->session->unset_userdata('id');
        $this->session->unset_userdata('nama');
        $this->session->unset_userdata('password');
        $this->session->unset_userdata('level');
        
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Anda Telah Keluar !</div>');
        redirect('Guest');
    }
}
