<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

include('koneksi.php');

// Inisialisasi variabel
$id = $judul = $pengarang = $gambar = $negara = $bahasa = $genre = $penerbit = $publish_date = $pages = $synopsis = "";

// Memeriksa apakah parameter ID buku telah diterima
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mendapatkan data buku berdasarkan ID
    $sql = "SELECT * FROM books WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Mengisi variabel dengan data buku
        $row = $result->fetch_assoc();
        $judul = $row['title'];
        $pengarang = $row['author'];
        $gambar = $row['image_url'];
        $negara = $row['country'];
        $bahasa = $row['language'];
        $genre = $row['genre'];
        $penerbit = $row['publisher'];
        $publish_date = $row['publish_date'];
        $pages = $row['pages'];
        $synopsis = $row['synopsis'];
    } else {
        echo "Data buku tidak ditemukan.";
    }
}

// Memproses form jika disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data dari form
    $id = $_POST['id'];
    $judul = $_POST['title'];
    $pengarang = $_POST['author'];
    $negara = $_POST['country'];
    $bahasa = $_POST['language'];
    $genre = $_POST['genre'];
    $penerbit = $_POST['publisher'];
    $publish_date = $_POST['publish_date'];
    $pages = $_POST['pages'];
    $synopsis = $_POST['synopsis'];

    // Menangani upload gambar
    $gambar_name = $_FILES['image']['name'];
    $gambar_tmp = $_FILES['image']['tmp_name'];
    $gambar_size = $_FILES['image']['size'];
    $gambar_error = $_FILES['image']['error'];

    // Inisialisasi variabel $gambar
    $gambar = "";

    // Cek apakah ada file gambar yang diupload
    if ($gambar_size > 0 && $gambar_error == 0) {
        // Direktori tempat menyimpan gambar
        $upload_dir = "assets/gambar/";

        // Menghasilkan nama unik untuk gambar
        $gambar_destination = $upload_dir . $gambar_name;

        // Pindahkan gambar ke direktori yang ditentukan
        move_uploaded_file($gambar_tmp, $gambar_destination);

        // Hapus gambar lama jika ada
        if (!empty($gambar)) {
            unlink($gambar);
        }

        // Menyimpan nama file gambar ke variabel
        $gambar = $gambar_name;
    }


    // Proses update data buku
    $sql = "UPDATE books SET 
            title = '$judul',
            author = '$pengarang',
            image_url = '$gambar',
            country = '$negara',
            language = '$bahasa',
            genre = '$genre',
            publisher = '$penerbit',
            publish_date = '$publish_date',
            pages = $pages,
            synopsis = '$synopsis'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Data buku berhasil diupdate.";
        redirect('admin/bukuadmin');
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transnikel</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/elegant-icons.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/plyr.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/nice-select.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/owl.carousel.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/slicknav.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css?v=') . time()?>" type="text/css">
</head>

<body>
<div class="wrapper">
        <!-- Sidebar -->
        <div id="sidebar">
            <div class="sidebar-header">
            <img style="margin-left: 50px;" src="<?= base_url('assets/') ?>img/Transnikel.png" alt="logo">
            </div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="<?= base_url('penerbit/dasboard') ?>">Dashboard</a>
                </li>
                <li>
                    <a href="<?= base_url('penerbit/bukupenerbit') ?>">Manage Kendaraan</a>
                </li>
                <li>
                    <a href="<?= base_url('penerbit/transaksipenerbit') ?>">Manage Pemesanan</a>
                </li>
                <!-- Add more items as needed -->
            </ul>

            <!-- Profile Image in Sidebar -->
            <a href="<?= base_url('penerbit/profil') ?>">
                <img style="border-radius: 100px;" class="img2 profile-image" src="<?= base_url('assets/') ?>img/profil benaar.png" alt="">
            </a>
        </div>

        <!-- Page Content -->
        <div id="content">
            <!-- Search Box -->
            <!-- Admin Dashboard Cards -->
            <div class="container">
                <div class="row" mt-4>
                    <div class="col-md-4">
                        <a href="#" class="card-link">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Update Kendaraan</h5>
                                    <p class="card-text"></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    <!-- Add more cards as needed -->
                </div>
                <div class="row mt-4">
                    <div class="col-md-8">
                    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $id; ?>">
                        <div class="form-group">
                            <label for="title">Merk Kendaraan</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?= $judul; ?>" required>
                        </div>
                        <!-- Tambahkan input file untuk gambar -->
                        <div class="form-group">
                            <label for="image">Gambar Kendaraan</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        </div>
                        <div class="form-group">
                            <label for="author">Harga BBM</label>
                            <input type="text" class="form-control" id="author" name="author" value="<?= $pengarang; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="genre">Jumlah</label>
                            <input type="text" class="form-control" id="genre" name="genre" value="<?= $genre; ?>">
                        </div>
                        <button type="submit" class="admin-bton">Update Buku</button>
                    </form>
                    </div>
                </div>
            </div>
        </div>
        
        <hr>
        <footer id="footer">
            <div class="container text-center py-3">
                <p style="margin-right: 550px;" >© 2024 Transport - All rights reserved Email: sultanmanggalia@gmail.com</p>
            </div>
        </footer>
    </div>

    <!-- Add your scripts here if needed -->
    <script src="<?= base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/player.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.nice-select.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/mixitup.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.slicknav.js') ?>"></script>
    <script src="<?= base_url('assets/js/owl.carousel.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>

    <!-- Skrip JavaScript -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Ambil elemen input dan produk
            var searchInput = document.getElementById('searchInput');
            var products = document.querySelectorAll('.product__item');

            // Tambahkan event listener pada input pencarian
            searchInput.addEventListener('input', function () {
                var keyword = searchInput.value.toLowerCase();

                // Loop melalui setiap produk dan sembunyikan/munculkan sesuai keyword
                products.forEach(function (product) {
                    var productName = product.querySelector('h5').innerText.toLowerCase();
                    var match = productName.includes(keyword);
                    product.style.display = match ? 'block' : 'none';
                });
            });
        });
    </script>
</body>

</html>
