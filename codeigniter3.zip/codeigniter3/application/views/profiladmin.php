<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transnikel</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/elegant-icons.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/plyr.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/nice-select.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/owl.carousel.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/slicknav.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin-profile.css?v=') . time()?>" type="text/css">
</head>

<body>
<div class="wrapper">
        <!-- Sidebar -->
        <div id="sidebar">
            <div class="sidebar-header">
            <img style="margin-left: 50px;" src="<?= base_url('assets/') ?>img/Transnikel.png" alt="logo">
            </div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="<?= base_url('admin/dasboard') ?>">Dashboard</a>
                </li>
                <li>
                    <a href="<?= base_url('admin/bukuadmin') ?>">Manage Buku</a>
                </li>
                <li>
                    <a href="<?= base_url('admin/transaksiadmin') ?>">Manage Transaksi</a>
                </li>
                <!-- Add more items as needed -->
            </ul>

            <!-- Profile Image in Sidebar -->
            <img style="border-radius: 100px;" class="img2 profile-image" src="<?= base_url('assets/') ?>img/profil benaar.png" alt="Profile Image">
        </div>

        <!-- Page Content -->
        <div id="content">
            <!-- Search Box -->

            <!-- Admin Dashboard Cards -->
            <section class="blog-details spad">
                <div class="container">
                    <div class="row d-flex justify-content-center">
                        <img class="img3" src="<?= base_url('assets/') ?>img/Untitled design.png">
                        
                    </div>
                </div>
                <div class="container">
    <div class="row d-flex justify-content-center">
        <div class="text">
            <p></p>
            <p><?php echo $user['nama']; ?></p>
        </div>
    </div>
</div>
<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="anime__details__btn">
            <a class="wotch-btn"><span>Profil</span></a>
        </div>
    </div>
</div>
<p></p>
<div class="container">
    <div class="fom">
        <label for="exampleInputEmail1" style="font-weight: bold; margin-top: 10px;">Username</label>
        <hr style="border: 1px solid #000;">
        <a><?php echo $user['nama']; ?></a>
        <p></p>

        <label for="exampleInputEmail1" style="font-weight: bold; margin-bottom: 10px;">Change Password</label>
        <hr style="border: 1px solid #000;">
        <!-- Form Penggantian Password -->
        <form action="<?= base_url('user/ganti_password') ?>" method="post">
            <div class="form-group">
                <label for="password_baru">New Password</label>
                <input type="password" name="password_baru" class="form-control">
            </div>
            <div class="form-group">
                <label for="konfirmasi_password">Confirm New Password</label>
                <input type="password" name="konfirmasi_password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
        <!-- Akhir Form Penggantian Password -->        
        <div class="anime__details__btn">
            <a href="<?= base_url('auth') ?>" class="wetch-btn"><span>Logout</span></a>
        </div>
    </div>
</div>
                </section>
                    <!-- Add more cards as needed -->
                </div>
            </div>
        </div>
        <hr>
        <footer id="footer">
            <div class="container text-center py-3">
                <p style="margin-right: 550px;" >© 2024 Transport - All rights reserved Email: sultanmanggalia@gmail.com</p>
            </div>
        </footer>
    </div>

    <!-- Add your scripts here if needed -->
    <script src="<?= base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/player.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.nice-select.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/mixitup.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.slicknav.js') ?>"></script>
    <script src="<?= base_url('assets/js/owl.carousel.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>

    <!-- Skrip JavaScript -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Ambil elemen input dan produk
            var searchInput = document.getElementById('searchInput');
            var products = document.querySelectorAll('.product__item');

            // Tambahkan event listener pada input pencarian
            searchInput.addEventListener('input', function () {
                var keyword = searchInput.value.toLowerCase();

                // Loop melalui setiap produk dan sembunyikan/munculkan sesuai keyword
                products.forEach(function (product) {
                    var productName = product.querySelector('h5').innerText.toLowerCase();
                    var match = productName.includes(keyword);
                    product.style.display = match ? 'block' : 'none';
                });
            });
        });
    </script>
</body>

</html>
