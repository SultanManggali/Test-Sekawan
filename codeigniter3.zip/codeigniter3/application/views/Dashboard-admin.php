<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
// Include koneksi.php
include 'koneksi.php';

// Query untuk mendapatkan data buku
$query = "SELECT * FROM books";
$result = $conn->query($query);

// Cek apakah query berhasil
if ($result) {
    // Fetch hasil query ke dalam array
    $buku_data = $result->fetch_all(MYSQLI_ASSOC);
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

// Query untuk mendapatkan jumlah total buku
$totalBukuQuery = "SELECT COUNT(*) as total FROM books";
$totalBukuResult = $conn->query($totalBukuQuery);

// Inisialisasi variabel total buku
$totalBuku = 0;

// Cek apakah query berhasil
if ($totalBukuResult) {
    // Ambil hasil query
    $totalBukuData = $totalBukuResult->fetch_assoc();
    $totalBuku = $totalBukuData['total'];
} else {
    echo "Error: " . $totalBukuQuery . "<br>" . $conn->error;
}

// Query untuk mendapatkan jumlah total transaksi
$totalTransaksiQuery = "SELECT COUNT(*) as total FROM transaksi"; // Ganti 'transactions' dengan nama tabel transaksi Anda
$totalTransaksiResult = $conn->query($totalTransaksiQuery);

// Inisialisasi variabel total transaksi
$totalTransaksi = 0;

// Cek apakah query berhasil
if ($totalTransaksiResult) {
    // Ambil hasil query
    $totalTransaksiData = $totalTransaksiResult->fetch_assoc();
    $totalTransaksi = $totalTransaksiData['total'];
} else {
    echo "Error: " . $totalTransaksiQuery . "<br>" . $conn->error;
}


// Tutup koneksi
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transnikel</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/elegant-icons.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/plyr.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/nice-select.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/owl.carousel.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/slicknav.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css?v=') . time()?>" type="text/css">
</head>

<body>
<div class="wrapper">
        <!-- Sidebar -->
        <div id="sidebar">
            <div class="sidebar-header">
            <img style="margin-left: 50px;" src="<?= base_url('assets/') ?>img/Transnikel.png" alt="logo">
            </div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="<?= base_url('admin/dasboard') ?>">Dashboard</a>
                </li>
                <li>
                    <a href="<?= base_url('admin/bukuadmin') ?>">Manage Kendaraan</a>
                </li>
                <li>
                    <a href="<?= base_url('admin/transaksiadmin') ?>">Manage Pemesanan</a>
                </li>
                <!-- Add more items as needed -->
            </ul>

            <!-- Profile Image in Sidebar -->
            <a href="<?= base_url('admin/profil') ?>">
                <img style="border-radius: 100px;" class="img2 profile-image" src="<?= base_url('assets/') ?>img/profil benaar.png" alt="">
            </a>
        </div>

        <!-- Page Content -->
        <div id="content">
            <!-- Search Box -->
            <div class="container">
                <div class="row mt-3">
                    <div class="col-md-4">
                    <p>Selamat Datang, Admin</p>
                    </div>
                </div>
            </div>

            <!-- Admin Dashboard Cards -->
            <div class="container">
                <div class="row" mt-4>
                    <div class="col-md-4">
                        <a href="<?= base_url('admin/bukuadmin') ?>" class="card-link">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Kendaraan:</h5>
                                    <i class="fa-solid fa-book-open-reader fa-2xl" style="color: #000000; margin-left: 200px;"></i>
                                    <i class="fa-solid fa-chevron-right" style="color: #000000; margin-left: 50px; font-size: 25px;"></i>
                                    <p class="card-text"><?= $totalBuku ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="<?= base_url('admin/transaksiadmin') ?>" class="card-link">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Pemesanan:</h5>
                                    <i class="fa-solid fa-dollar-sign fa-2xl" style="color: #000000; margin-left: 200px;"></i>
                                    <i class="fa-solid fa-chevron-right" style="color: #000000; margin-left: 50px; font-size: 25px;"></i>
                                    <p class="card-text"><?= $totalTransaksi ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- Grafik -->
                    <div class="container">
                        <div class="row mt-4">
                            <div class="col-md-8">
                                <canvas id="monthlyOrdersChart" width="400" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                    <!-- Add more cards as needed -->
                </div>
            </div>
        </div>
        <hr>
        <footer id="footer">
            <div class="container text-center py-3">
                <p style="margin-right: 550px;" >© 2024 Transport - All rights reserved Email: sultanmanggalia@gmail.com</p>
            </div>
        </footer>
    </div>

    <!-- Add your scripts here if needed -->
    <script src="<?= base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/player.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.nice-select.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/mixitup.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.slicknav.js') ?>"></script>
    <script src="<?= base_url('assets/js/owl.carousel.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>

    <!-- Skrip JavaScript -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Ambil elemen input dan produk
            var searchInput = document.getElementById('searchInput');
            var products = document.querySelectorAll('.product__item');

            // Tambahkan event listener pada input pencarian
            searchInput.addEventListener('input', function () {
                var keyword = searchInput.value.toLowerCase();

                // Loop melalui setiap produk dan sembunyikan/munculkan sesuai keyword
                products.forEach(function (product) {
                    var productName = product.querySelector('h5').innerText.toLowerCase();
                    var match = productName.includes(keyword);
                    product.style.display = match ? 'block' : 'none';
                });
            });
        });
        document.addEventListener("DOMContentLoaded", function () {
            // Data bulanan (ganti dengan data sebenarnya Anda)
            var monthlyData = {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Pemesanan Kendaraan 2023',
                    backgroundColor: '#352F44', 
                    borderColor: '#FFFFF',
                    borderWidth: 1,
                    data: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65]
                }]
            };

            var ctx = document.getElementById('monthlyOrdersChart').getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: monthlyData,
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
</body>

</html>
