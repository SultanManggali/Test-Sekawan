<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
// Include koneksi.php
include 'koneksi.php';

// Query untuk mendapatkan data transaksi
$query_transaksi = "SELECT id, name, tanggal_pesan, jenis_kendaraan, penjemputan, penurunan FROM transaksi";
$result_transaksi = $conn->query($query_transaksi);

// Cek apakah query berhasil
if ($result_transaksi) {
    // Fetch hasil query ke dalam array
    $transaksi_data = $result_transaksi->fetch_all(MYSQLI_ASSOC);
} else {
    echo "Error: " . $query_transaksi . "<br>" . $conn->error;
}

// Query untuk mendapatkan jumlah total transaksi
$totalTransaksiQuery = "SELECT COUNT(*) as total FROM transaksi"; // Ganti 'transactions' dengan nama tabel transaksi Anda
$totalTransaksiResult = $conn->query($totalTransaksiQuery);

// Inisialisasi variabel total transaksi
$totalTransaksi = 0;

// Cek apakah query berhasil
if ($totalTransaksiResult) {
    // Ambil hasil query
    $totalTransaksiData = $totalTransaksiResult->fetch_assoc();
    $totalTransaksi = $totalTransaksiData['total'];
} else {
    echo "Error: " . $totalTransaksiQuery . "<br>" . $conn->error;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Transaksi Template">
    <meta name="keywords" content="Transaksi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transniikel</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/elegant-icons.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/plyr.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/nice-select.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/owl.carousel.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/slicknav.min.css?v=') . time()?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css?v=') . time()?>" type="text/css">
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div id="sidebar">
            <div class="sidebar-header">
            <img style="margin-left: 50px;" src="<?= base_url('assets/') ?>img/Transnikel.png" alt="logo">
            </div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="<?= base_url('penerbit/dasboard') ?>">Dashboard</a>
                </li>
                <li>
                    <a href="<?= base_url('penerbit/bukupenerbit') ?>">Manage Kendaraan</a>
                </li>
                <li>
                    <a href="<?= base_url('penerbit/transaksipenerbit') ?>">Manage Pemesanan</a>
                </li>
                <!-- Add more items as needed -->
            </ul>
            <!-- Profile Image in Sidebar -->
            <a href="<?= base_url('penerbit/profil') ?>">
                <img style="border-radius: 100px;" class="img2 profile-image" src="<?= base_url('assets/') ?>img/profil benaar.png" alt="">
            </a>
        </div>

        <!-- Page Content -->
        <div id="content">
            <!-- Search Box -->
            <div class="container">
                <div class="row mt-3">
                    <div class="col-md-4">
                        <div style="margin-top: 30px;" class="input-group">
                            <input type="text" class="form-control" id="searchInput" placeholder="Search here"
                                aria-label="Recipient's username">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-magnifying-glass"
                                        style="color:#ffffff;"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Admin Dashboard Cards -->
            <div class="container">
                <div class="row" mt-4>
                    <div class="col-md-4">
                        <a href="<?= base_url('admin/total_users') ?>" class="card-link">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Total Pemesanan:</h5>
                                    <p class="card-text"><?= $totalTransaksi ?></p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="btn_admin">
                            <a href="<?= base_url('penerbit/tambahtransaksi') ?>" class="admin-btn"><span>Tambah Pemesanan</span></a>
                    </div>

                    <div class="col-md-12">
                        <h2>Data Pemesanan</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama</th>
                                    <th>Tanggal Pesan</th>
                                    <th>Jenis Kendaraan</th>
                                    <th>Penjemputan</th>
                                    <th>Penurunan</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through data and populate the table -->
                                <?php
                                if (isset($transaksi_data) && is_array($transaksi_data)) {
                                    $nomor_baris = 1;
                                    foreach ($transaksi_data as $transaksi) {
                                        echo "<tr>";
                                        echo "<tr class='product__item'>"; // Tambahkan class di sini
                                        echo "<td>{$nomor_baris}</td>";
                                        echo "<td>{$transaksi['name']}</td>";
                                        echo "<td>{$transaksi['tanggal_pesan']}</td>";
                                        echo "<td>{$transaksi['jenis_kendaraan']}</td>";
                                        echo "<td>{$transaksi['penjemputan']}</td>";
                                        echo "<td>{$transaksi['penurunan']}</td>";
                                        echo "<td><a href='?id={$transaksi['id']}'><i class='fas fa-trash-alt'></i></a></td>";
                                        echo "<td><a href='" . base_url("penerbit/editbuku?id={$transaksi['id']}") . "'><i class='fas fa-edit'></i></a></td>";
                                        // Ganti 'path/to/your/image/directory/' sesuai dengan direktori penyimpanan gambar Anda
                                        echo "</tr>";
                                        $nomor_baris++;
                                    }
                                } else {
                                    echo "<tr><td colspan=''>Tidak ada data buku</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                        if(isset($_GET['id'])){
                            $deleteId = $_GET['id'];
                            $deleteQuery = "DELETE FROM transaksi WHERE id = '$deleteId'";
                            $deleteResult = $conn->query($deleteQuery);

                            if ($deleteResult) {
                            } else {
                                echo "Error: " . $deleteQuery . "<br>" . $conn->error;
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
            </div>
        </div>
        <hr>
        <footer id="footer">
            <div class="container text-center py-3">
                <p style="margin-right: 550px; " >© 2024 Transport - All rights reserved Email: sultanmanggalia@gmail.com</p>
            </div>
        </footer>
    </div>
    </div>

    <!-- Add your scripts here if needed -->
    <script src="<?= base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/player.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.nice-select.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/mixitup.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/jquery.slicknav.js') ?>"></script>
    <script src="<?= base_url('assets/js/owl.carousel.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>

</html>

    <!-- Skrip JavaScript -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
    // Ambil elemen input dan produk
    var searchInput = document.getElementById('searchInput');
    var products = document.querySelectorAll('.product__item');

    // Tambahkan event listener pada input pencarian
    searchInput.addEventListener('input', function () {
        var keyword = searchInput.value.toLowerCase();

        // Loop melalui setiap produk dan sembunyikan/munculkan sesuai keyword
        products.forEach(function (product) {
            var productName = product.querySelector('td:nth-child(2)').innerText.toLowerCase(); // Sesuaikan indeks kolom
            var match = productName.includes(keyword);
            product.style.display = match ? 'table-row' : 'none';
                });
            });
        });
    </script>
